"use client"

import { useState } from "react"
import axios from "axios"
import { ArrowLeft, Upload, FileText, Loader2, Download, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { LoadingModal } from "@/components/loading-modal"

const BACKEND_BASE = process.env.NEXT_PUBLIC_BACKEND_API_URL || "http://localhost:8000"

export default function FileFormatterPage() {
  const [file, setFile] = useState(null)
  const [formattedText, setFormattedText] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [showLoadingModal, setShowLoadingModal] = useState(false)

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0]
    setFile(selectedFile)
    setError("")
    setFormattedText("")
  }

  const handleUpload = async () => {
    if (!file) {
      setError("Please select a file first!")
      return
    }

    const formData = new FormData()
    formData.append("file", file)
    setLoading(true)
    setError("")
    setFormattedText("")
    setShowLoadingModal(true)

    try {
      const response = await axios.post(`${BACKEND_BASE}/upload/`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      setFormattedText(response.data.formatted_text)
    } catch (error) {
      console.error(error)
      setError(error.response?.data?.detail || "An error occurred while uploading and processing the file.")
    } finally {
      setLoading(false)
      setShowLoadingModal(false)
    }
  }

  const supportedFormats = [
    "PDF",
    "DOCX",
    "DOC",
    "TXT",
    "RTF",
    "HTML",
    "XLS",
    "XLSX",
    "CSV",
    "Images (JPG, PNG, TIFF)",
    "ZIP",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900 dark:bg-black text-white">
      {/* Header */}
      <header className="border-b bg-black/95 dark:bg-black/90 backdrop-blur supports-[backdrop-filter]:bg-black/60 dark:supports-[backdrop-filter]:bg-black/80 sticky top-0 z-50 dark:border-slate-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-white hover:text-blue-400 transition-colors">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Projects
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <FileText className="h-6 w-6 text-blue-400" />
              <h1 className="text-xl font-bold text-white">Universal File Text Formatter</h1>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-6 shadow-lg">
            <span className="text-2xl text-white">📄</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4 text-white">Universal File Text Formatter</h1>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto">
            Extract and format text from various file types including documents, spreadsheets, images, and archives.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="space-y-6">
            <Card className="bg-black border border-blue-700/50 transition-all duration-300 hover:border-blue-500/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Upload className="h-5 w-5 text-blue-400" />
                  Upload Your File
                </CardTitle>
                <CardDescription className="text-gray-400">
                  Choose a file to extract and format its text content
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="relative">
                  <input
                    type="file"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    accept=".pdf,.docx,.doc,.txt,.rtf,.html,.xls,.xlsx,.csv,.jpg,.jpeg,.png,.tiff,.zip"
                  />
                  <div
                    className={`
                      border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200
                      ${
                        file
                          ? "border-blue-400 bg-blue-950/20"
                          : "border-blue-600 hover:border-blue-400 hover:bg-blue-950/10"
                      }
                    `}
                  >
                    <span className="text-4xl mb-4 block">{file ? "✅" : "📁"}</span>
                    <p className="text-white font-medium mb-2">{file ? file.name : "Click to select or drag & drop"}</p>
                    <p className="text-gray-400 text-sm">
                      {file ? `File size: ${(file.size / 1024 / 1024).toFixed(2)} MB` : "Select a file to get started"}
                    </p>
                  </div>
                </div>

                <Button
                  onClick={handleUpload}
                  className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-indigo-500 hover:to-blue-500 text-white py-3 transition-colors duration-300"
                  disabled={!file || loading}
                >
                  {loading ? (
                    <div className="flex items-center justify-center">
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Processing File...
                    </div>
                  ) : (
                    <>
                      <Upload className="h-4 w-4 mr-2" />📤 Upload & Format
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Supported Formats */}
            <Card className="bg-black border border-blue-700/50 transition-all duration-300 hover:border-blue-500/50">
              <CardHeader>
                <CardTitle className="text-white text-lg">Supported File Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {supportedFormats.map((format, index) => (
                    <div
                      key={index}
                      className="flex items-center space-x-2 p-2 bg-gray-800 rounded-lg border border-blue-800"
                    >
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-gray-300">{format}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            {/* Error Display */}
            {error && (
              <Alert variant="destructive" className="bg-red-900/50 border-red-700">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}

            {/* Formatted Text Display */}
            <Card className="bg-black border border-blue-700/50 transition-all duration-300 hover:border-blue-500/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="h-5 w-5 text-blue-400" />📑 Formatted Text
                  </CardTitle>
                  {formattedText && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-blue-600 text-blue-400 hover:bg-blue-950/20"
                      onClick={() => {
                        navigator.clipboard.writeText(formattedText)
                      }}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Copy Text
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <pre
                    className="
                      whitespace-pre-wrap word-wrap break-word p-4 
                      bg-gray-900 border border-blue-800 rounded-lg 
                      max-h-96 overflow-y-auto text-gray-100 text-sm 
                      leading-relaxed font-mono
                    "
                  >
                    {formattedText || "Your formatted text will appear here once the upload completes."}
                  </pre>
                  {!formattedText && !loading && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <FileText className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                        <p className="text-gray-500">Upload a file to see the extracted text</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Features Info */}
            <Card className="bg-black border border-blue-700/50 transition-all duration-300 hover:border-blue-500/50">
              <CardHeader>
                <CardTitle className="text-white text-lg">How It Works</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-blue-500">1</span>
                  </div>
                  <p className="text-sm text-gray-400">Upload any supported file type</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-indigo-500/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-indigo-500">2</span>
                  </div>
                  <p className="text-sm text-gray-400">AI processes and extracts text content</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-500/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-blue-500">3</span>
                  </div>
                  <p className="text-sm text-gray-400">Get formatted, readable text output</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Loading Modal */}
        <LoadingModal
          isOpen={showLoadingModal}
          onClose={() => setShowLoadingModal(false)}
          projectName="Universal File Text Formatter"
        />
      </main>
    </div>
  )
}
